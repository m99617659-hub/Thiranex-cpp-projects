
#include <iostream>
#include <fstream>
using namespace std;
int main() {
    int choice,id;
    string name;
    while(true){
        cout<<"\n1.Add Student\n2.Display Students\n3.Exit\nChoice: ";
        cin>>choice;
        if(choice==1){
            cout<<"Enter ID and Name: ";
            cin>>id>>name;
            ofstream file("students.txt",ios::app);
            file<<id<<" "<<name<<endl;
            file.close();
        }else if(choice==2){
            ifstream file("students.txt");
            while(file>>id>>name) cout<<id<<" "<<name<<endl;
            file.close();
        }else break;
    }
}
