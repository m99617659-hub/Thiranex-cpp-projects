
#include <iostream>
using namespace std;
int main(){
    cout<<"Library Management System\n";
    cout<<"Features: Add Book, Issue Book, Return Book, Search Book\n";
    return 0;
}
