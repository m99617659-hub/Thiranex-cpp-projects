
#include <iostream>
using namespace std;
int main(){
    double balance=0,amount;
    int ch;
    while(true){
        cout<<"\n1.Deposit\n2.Withdraw\n3.Check Balance\n4.Exit\n";
        cin>>ch;
        if(ch==1){cin>>amount; balance+=amount;}
        else if(ch==2){cin>>amount; if(amount<=balance) balance-=amount;}
        else if(ch==3) cout<<"Balance: "<<balance<<endl;
        else break;
    }
}
